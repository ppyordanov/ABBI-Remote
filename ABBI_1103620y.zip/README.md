# abbi
An Android application built atop a custom library module ( 'abbi_library' ) used to control the ABBI bracelet developed by IIT (Italian Institute of Technology). The project will follow the client-server software development paradigm. The server is going to be tied to a central data store and communicate with the Android app via a REST API.

Source: https://github.com/ppyordanov/ABBI-Remote
